package com.actions.admin;

import java.util.Collection;
import java.util.List;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.ResultPath;
import org.springframework.beans.factory.annotation.Autowired;

import com.actions.BaseAction;
import com.bo.Admin;
import com.bo.Destination;
import com.bo.WordPolarity;
import com.services.AdminService;
import com.services.DestinationService;
import com.services.SentimentAnalysis;

@ResultPath(value="/pages/")
public class AdminActions extends BaseAction{
	
	private Destination destination;
	
	private Collection<Destination> admindestinations;
	
	@Autowired
	private AdminService adminService;

	private WordPolarity wordPolarity;
	@Autowired
	private SentimentAnalysis sentimentAnalysis;
	/*ici
	 */
	 
	@Autowired
	private DestinationService destinationService;
	
	//rec id
	@Action(value="/dropDest" , results= {  @Result(name="success", location="DropDestination.jsp")} )
	public String showDropDestinationForm()
	{
		//on reccupere l'id de la destination
		
		getSession().setAttribute("idDest",Long.valueOf(getRequest().getParameter("id")));
		
		
		return SUCCESS;
	}
	@Action(value="/addDestination" , results= {  @Result(name="success",type="redirectAction", location="getAllDestinations")} )
	public String dropDestination()
	{
		// la destination on va la reccuperer de la session avec BaseAction
		
		Long id = (Long) getSession().getAttribute("idDest");
		
		// TODO : si destin introubavle
		
		
		Destination dest = (Destination)destinationService.getDestinationById(id);
		
		List<Destination> dests=destinationService.getAllDestinations();
		dests.remove(dest);
		
		destinationService.updateDestination(dest);
		
		return SUCCESS;
	}
	
	
	
	
	
	
	/*
	 * jusquici
	 */
	@Action(value="/addWord" , results= {  @Result(name="success", location="addWordForm.jsp")} )
	public String addWord()
	{
		sentimentAnalysis.addWord(wordPolarity);
		
		addActionMessage("Mot bien ajouté ");
		
		return SUCCESS;
	}
	
	@Action(value="/showAddDestinationFormAdmin" , results= {  @Result(name="success", location="addDestinationForm.jsp")} )
	public String showAddDestinationFormAdmin()
	{
		//on reccupere le admin id
		
		getSession().setAttribute("idAdmin",Long.valueOf(getRequest().getParameter("id")));
		
		
		return SUCCESS;
	}
	
	
	@Action(value="/addDestination" , results= {  @Result(name="success",type="redirectAction", location="getAllDestinations")} )
	public String addDestination()
	{
		// la destination on va la reccuperer de la session avec BaseAction
		
		Long id = (Long) getSession().getAttribute("idAdmin");
		
		// TODO : si admin introubavle
		
		Admin admin = (Admin) adminService.getAdminById(id);
		
	    admin.addDestination(destination);
		
		return SUCCESS;
	}
	
	
	@Action(value="/GetDestinationsAddedByAdmin" , results= {  @Result(name="success", location="listDestinationAddedByAdmin.jsp")} )
	public String GetDestinationsAddedByAdmin()
	{
		Long id = (Long) getSession().getAttribute("idUser");
		
		// TODO : si user introubavle
		
		Admin admin = (Admin) adminService.getAdminById(id);
		
		admindestinations=admin.getDestinations();
		
		return SUCCESS;
	}

	public WordPolarity getWordPolarity() {
		return wordPolarity;
	}

	public void setWordPolarity(WordPolarity wordPolarity) {
		this.wordPolarity = wordPolarity;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public Collection<Destination> getAdmindestinations() {
		return admindestinations;
	}

	public void setAdmindestinations(Collection<Destination> admindestinations) {
		this.admindestinations = admindestinations;
	}

	
	
}
	
	